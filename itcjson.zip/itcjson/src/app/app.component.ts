import { Component } from '@angular/core';
import studentsData from "./studentsdata.json";

interface Student{
  id: number;
  name:string;
  email:string ;
  gender:string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'itcjson';

  students:Student[]=studentsData;
}
